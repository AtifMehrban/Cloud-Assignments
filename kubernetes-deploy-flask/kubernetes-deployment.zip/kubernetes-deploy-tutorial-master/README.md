# kubernetes-deploy-tutorial
This code is made for my youtube channel and corresponding to video given below.


<p align="center"> 
    <a href="https://youtu.be/XQNNAeyMAkk" target="_blank">
    <img src="http://img.youtube.com/vi/XQNNAeyMAkk/0.jpg"></img>
  </a>
</p>
